module ZUART_Adapter(
    //common signals.
	input wire iClk, //input clock.
	input wire iRstN,
	input wire iEn,

    //UART.
    output wire oUART_TxD,
    output reg oLED,

    //Read Data from FIFO.
    input wire iFIFOEmptyFlag,
    output reg oFIFORdEn,
    input wire [15:0] iFIFODataOut,

    //Temperature Updated.
    input wire [15:0] iTempData
);

//Tx Random UART Data at 1Mbps.
//generate 1MHz Clock, //48MHz/1MHz=48.
//generate 4MHz Clock, //48MHz/4MHz=12.
//generate 8MHz Clock, //48MHz/8MHz=6.
reg [15:0] tx_data_16bits;
reg [7:0] tx_data;
reg tx_en;
wire tx_done;
ZUART_Tx #(.Freq_divider(12)) uart_u1
(
	.iClk(iClk),
	.iRst_N(iRstN),
	.iData(tx_data),
	
	//pull down iEn to start transmition until pulse done oDone was issued.
	.iEn(tx_en),
	.oDone(tx_done),
	.oTxD(oUART_TxD)
);

//Driven by step_i.
reg [7:0] step_i;
reg [15:0] fifo_data_out;
reg [31:0] cnt_led;
//UART Protocol Format:
//55 High-Byte Low-Byte Temperature-Byte.
//0.0078125=2^(-7)

//expand 1 bit for symbol.
reg unsigned [15:0] SensorData; 
reg symbol_bit;
always @(posedge iClk or negedge iRstN) 
if(!iRstN) begin
    step_i<=0; tx_en<=0; tx_data<=0; cnt_led<=0; oLED<=0; 
end
else begin
    case(step_i)
        0: //transmit frame head byte 0x55.
            if(tx_done) begin tx_en<=0; step_i<=step_i+1; end
            else begin tx_en<=1; tx_data<=8'h55; end
        1: //Fetch data from FIFO when it's not empty.
            if(!iFIFOEmptyFlag) begin oFIFORdEn<=1; step_i<=step_i+1; end
        2: //fetch data at the 2nd clock after ReadEnable.
            begin fifo_data_out<=/*16'h1987*/iFIFODataOut; oFIFORdEn<=0; step_i<=step_i+1; end
        3: //transmit high 8 bits.
            if(tx_done) begin tx_en<=0; step_i<=step_i+1; 
            //SensorData<=16'h8000; //0xFF,MSB is 1, 0x7F=255. => -255.
            //SensorData<=16'hF380; //0x98,MSB is 1, 0x18=24. => -24.
            SensorData<=16'h3200; //0x64,MSB is 0, 0x64=100. => +100.
            end
            else begin tx_en<=1; tx_data<=fifo_data_out[15:8]; end
        4: //transmit low 8 bits.
            if(tx_done) begin 
                tx_en<=0; step_i<=step_i+1; end
            else begin tx_en<=1; tx_data<=fifo_data_out[7:0]; end
        5:
            begin 
                //SensorData<=(SensorData[15])?(16'hFFFF-SensorData):(SensorData);
                //symbol_bit<=(SensorData[15])?(1):(0); 
                SensorData<=(iTempData[15])?(16'hFFFF-iTempData):(iTempData);
                symbol_bit<=(iTempData[15])?(1):(0); 
                step_i<=step_i+1; 
            end
        6:
            begin
                SensorData<=SensorData>>7;
                step_i<=step_i+1;
            end
        7: //Tx Temperature byte. -128 degree celsius ~ +127 degree celsius.
            if(tx_done) begin tx_en<=0; step_i<=step_i+1; end
            else begin tx_en<=1; tx_data<={symbol_bit,SensorData[6:0]}; end
        8: //Led Indicator.
            begin
                step_i<=0;
                /////////////////////////////////////////////////////////////////
                cnt_led<=(cnt_led==32'hF00-1)?(0):(cnt_led+1);
                oLED<=(cnt_led==32'hF00-1)?(~oLED):(oLED);
            end
        default:
                begin step_i<=0; end
    endcase
end
endmodule